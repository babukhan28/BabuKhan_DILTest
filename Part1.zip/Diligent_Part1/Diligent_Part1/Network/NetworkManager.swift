//
//  NetworkManager.swift
//  Weather
//

import Foundation
import Combine
import UIKit

// MARK: - NetworkError

enum NetworkError: Error {
    case invalidResponse
    case invalidURL
    case invalidData
    case network(Error?)
}


final class APIManager {
    
    // MARK: Properties
    static let shared = APIManager()
    static var commonHeader: [String: String] {
        ["Content-Type": "application/json"]
    }
    
    // MARK: Inits
    private init() {}
    
    // MARK: Methods
    func request<T: Decodable>(url: String) async throws ->  T {
        guard let url = URL(string: url) else {
            throw NetworkError.invalidURL
        }

        let (data, response) = try await URLSession.shared.data(from: url)

        guard (response as? HTTPURLResponse)?.statusCode == 200 else {
            throw NetworkError.invalidResponse
        }

        return try JSONDecoder().decode(T.self, from: data)
    }
}
