//
//  GhostDrawingModel.swift
//  GhostDrawing
// 

import UIKit

struct Line {
    var points: [CGPoint]
    var color: UIColor
}

class GhostDrawingModel {
    var lines: [Line] = []
    var currentLine: Line?
    var selectedColor: UIColor = .red
    var isErasing: Bool = false
    var eraserDelay: TimeInterval = 2
    
    /// Determines the delay duration for the appearance of a drawn line based on the selected color.
    ///
    /// This function takes a UIColor as input and returns the appropriate delay duration in seconds.
    /// The delay varies depending on the selected color: red (1 second), blue (3 seconds), green (5 seconds),
    /// and for other colors, it uses the delay value for the eraser mode.
    ///
    /// - Parameter color: The UIColor for which the delay duration is calculated.
    /// - Returns: The delay duration in seconds.
    func delayForColor(_ color: UIColor) -> TimeInterval {
        switch color {
        case .red:
            return 1
        case .blue:
            return 3
        case .green:
            return 5
        default:
            return eraserDelay
        }
    }
    
    /// Updates the selected drawing color and erasing mode.
    ///
    /// This function sets the `selectedColor` property to the provided color
    /// and the `isErasing` property to the provided erasing status.
    ///
    /// - Parameters:
    ///   - color: The UIColor representing the selected drawing color.
    ///   - erasing: A Boolean value indicating whether erasing mode should be enabled.
    func setSelectColorAndIsEraseEnable(color: UIColor, erasing: Bool) {
        selectedColor = color
        isErasing = erasing
    }
}
