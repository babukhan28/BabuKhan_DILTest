//
//  AppCoordinator.swift
//  Diligent_Part1
// 

import UIKit

// MARK: - AppCoordinator
class AppCoordinator: RootCoordinator {
    
    // MARK: Properties
    var navigationController: UINavigationController
    
    // MARK: Init
    init(navigationController: UINavigationController) {
        self.navigationController = navigationController
    }
    
    // MARK: Start method for coordinator
    func start() {
        let someViewController = SomeViewController()
        someViewController.initWithCoordinator(coordinator: self)
        navigationController.pushViewController(someViewController, animated: true)
    }
}
