//
//  ViewController+Extension.swift
//  Diligent_Part1
// 

import UIKit

extension UIViewController {
    func isIPhone() -> Bool {
        return UIDevice.current.userInterfaceIdiom == .phone
    }
}
