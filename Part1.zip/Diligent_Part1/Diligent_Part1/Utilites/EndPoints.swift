//
//  EndPoints.swift
//  Diligent_Part1
//

import Foundation

// MARK: - HTTPMethods
enum HTTPMethods: String {
    case Get = "GET"
    case Post = "POST"
}

// MARK: - EndPointType
protocol EndPointType {
    var path: String { get }
    var baseURL: String { get }
    var url: URL? { get }
    var method: HTTPMethods { get }
    var headers: [String: String]? { get }
}

// MARK: - EndPointItems
enum EndPointItems {
    case testreq
}

// MARK: - EndPointItems
extension EndPointItems: EndPointType {
    var path: String {
        switch self {
        case .testreq:
            return "testreq"
        }
    }
    
    var baseURL: String {
        switch self {
        case .testreq:
            return "testreq"
        }
    }
    
    var url: URL? {
        URL(string: "\(baseURL)\(path)")
    }
    
    var method: HTTPMethods {
        switch self {
        case .testreq:
            return .Get
        }
    }
    
    var headers: [String : String]? {
        APIManager.commonHeader
    }
}
