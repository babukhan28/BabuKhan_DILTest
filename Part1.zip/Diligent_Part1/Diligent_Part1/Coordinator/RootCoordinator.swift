//
//  RootCoordinator.swift
//  Diligent_Part1
// 

import UIKit

// MARK: - RootCoordinator
protocol RootCoordinator: AnyObject {
    var navigationController: UINavigationController { get set }
    func start()
}
