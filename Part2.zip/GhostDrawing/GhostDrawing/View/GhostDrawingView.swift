//
//  GhostDrawingView.swift
//  GhostDrawing
// 

import UIKit

class GhostDrawingView {
    
    // MARK: Properties
    private weak var canvasView: UIView!
    private let model: GhostDrawingModel
    
    // MARK: Inits
    init(canvasView: UIView, model: GhostDrawingModel) {
        self.canvasView = canvasView
        self.model = model
    }
    
    /// Initiates the drawing process by creating a new Line with the starting point and selected color.
    ///
    /// This function sets up a new Line with the provided point as its starting point and the currently selected color.
    /// The Line is then assigned to the currentLine property of the model to track the ongoing drawing.
    ///
    /// - Parameter point: The CGPoint representing the starting point of the drawing.
    func startDrawing(at point: CGPoint) {
        model.currentLine = Line(points: [point], color: model.selectedColor)
    }
    
    /// Continues the process of drawing by adding a new point to the current line.
    ///
    /// If a current line is being drawn, this function appends the provided point to the points of the line.
    ///
    /// - Parameter point: The CGPoint representing the new point to be added to the current line.
    func continueDrawing(at point: CGPoint) {
        model.currentLine?.points.append(point)
    }
    
    /// Finalizes the drawing process for the current line and adds it to the collection of lines.
    ///
    /// If a line exists in the currentLine property of the model, it appends the line to the list of lines.
    /// It also schedules the drawing of the line after a delay based on the selected color.
    /// After completion, it resets the currentLine to nil.
    func endDrawing() {
        if let line = model.currentLine {
            model.lines.append(line)
            DispatchQueue.main.asyncAfter(deadline: .now() + model.delayForColor(model.selectedColor)) { [weak self] in
                self?.drawLine(line: line)
            }
        }
        model.currentLine = nil
    }
}

private extension GhostDrawingView {
    /// Draws a line on the canvas view based on the provided Line data.
    ///
    /// - Parameters:
    ///   - line: The Line data containing points and color information.
    func drawLine(line: Line) {
        guard let canvasView = canvasView else { return }
        
        let path = UIBezierPath()
        path.move(to: line.points.first ?? .zero)
        
        for point in line.points {
            path.addLine(to: point)
        }
        
        let shapeLayer = CAShapeLayer()
        shapeLayer.path = path.cgPath
        shapeLayer.strokeColor = line.color.cgColor
        shapeLayer.lineWidth = model.isErasing ? 6 : 3
        shapeLayer.fillColor = UIColor.clear.cgColor
        
        canvasView.layer.addSublayer(shapeLayer)
    }
}
