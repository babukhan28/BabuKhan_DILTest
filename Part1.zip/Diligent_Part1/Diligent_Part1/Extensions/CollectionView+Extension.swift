//
//  CollectionView+Extension.swift
//  Diligent_Part1
//

import UIKit

extension UICollectionView {
    func registerNib<T: UICollectionViewCell>(forCellClass cellClass: T.Type)  {
        let nib = UINib(nibName: String(describing: cellClass), bundle: nil)
        register(nib, forCellWithReuseIdentifier: String(describing: cellClass))
    }
}
