//
//  SomeViewModel.swift
//  Diligent_Part1
// 

import Foundation
import Combine

class SomeViewModel {
    
    // MARK: Properties
    private var cancellables = Set<AnyCancellable>()
    private var dataArray: [SomeModel] = []
    private var coordinator: AppCoordinator?
    let reloadData = PassthroughSubject<Result<Void, NetworkError>, Never>()
    var numberOfData: Int {
        dataArray.count
    }

    // MARK: Init
    init(appCoordinator: AppCoordinator?) {
        self.coordinator = appCoordinator
    }
    
    // MARK: Methods
    /// Asynchronously fetches user data from a URL using `APIManager`,
    /// updating `dataArray` and signaling reload through `reloadData`.
    @MainActor func fetchUsers() {
        Task {
            do {
                dataArray = try await APIManager.shared.request(url: "userURL")
                reloadData.send(.success(()))
            } catch {
                reloadData.send(.failure(error as! NetworkError))
            }
        }
    }
}
