//
//  SomeModel.swift
//  Diligent_Part1
// 

import Foundation

struct SomeModel: Decodable {
    
}
