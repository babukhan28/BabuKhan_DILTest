//
//  GhostDrawingViewController.swift
//  GhostDrawing
//

import UIKit

class GhostDrawingViewController: UIViewController {
    
    // MARK: IBOutlets
    @IBOutlet weak var canvasView: UIView!
    @IBOutlet weak var colorButtonsStackView: UIStackView!
    
    // MARK: Properties
    let model = GhostDrawingModel()
    var drwaing: GhostDrawingView?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        drwaing = GhostDrawingView(canvasView: canvasView, model: model)
    }
    
    
    // MARK: IBActions
    /// Updating the selected color to red and disabling erasing mode.
    @IBAction func btnRedClicked(_ sender: UIButton) {
        model.setSelectColorAndIsEraseEnable(color: .red, erasing: false)
    }
    
    /// Updating the selected color to blue and disabling erasing mode.
    @IBAction func btnBlueClicked(_ sender: UIButton) {
        model.setSelectColorAndIsEraseEnable(color: .blue, erasing: false)
    }
    
    /// Updating the selected color to green and disabling erasing mode.
    @IBAction func btnGreenClicked(_ sender: UIButton) {
        model.setSelectColorAndIsEraseEnable(color: .green, erasing: false)
    }
    
    /// Updating the selected color to white and enabling erasing mode.
    @IBAction func btnEraseClicked(_ sender: UIButton) {
        model.setSelectColorAndIsEraseEnable(color: .white, erasing: true)
    }
}

// MARK: Extension For Touch Methods
extension GhostDrawingViewController {
    /// Overrides the touch event when a touch is initially detected on the canvas view.
    ///
    /// This function captures the first touch and extracts its location in the canvas view.
    /// It then initiates the drawing process by calling the `startDrawing(at:)` method of the drawing controller.
    ///
    /// - Parameters:
    ///   - touches: A set of UITouch objects representing the touches that have occurred.
    ///   - event: The UIEvent object representing the event associated with the touches.
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else { return }
        let point = touch.location(in: canvasView)
        drwaing?.startDrawing(at: point)
    }
    
    /// Overrides the touch event when a touch point is moved on the canvas view.
    ///
    /// This function captures the movement of the touch point and extracts its updated location within the canvas view.
    /// It then continues the drawing process by calling the `continueDrawing(at:)` method of the drawing controller.
    ///
    /// - Parameters:
    ///   - touches: A set of UITouch objects representing the touches that have occurred.
    ///   - event: The UIEvent object representing the event associated with the touches.
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else { return }
        let point = touch.location(in: canvasView)
        drwaing?.continueDrawing(at: point)
    }
    
    /// Overrides the touch event when a touch on the canvas view ends.
    ///
    /// This function marks the completion of a drawing action and signals the drawing controller to finalize the drawing process.
    ///
    /// - Parameters:
    ///   - touches: A set of UITouch objects representing the touches that have occurred.
    ///   - event: The UIEvent object representing the event associated with the touches.
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        drwaing?.endDrawing()
    }
}
