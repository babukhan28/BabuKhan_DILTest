//
//  SomeViewController.swift
//  Diligent_Part1
//

import UIKit
import Combine

class SomeViewController: UIViewController {
    
    // MARK: IBOutlet
    @IBOutlet private weak var collectionViewTopConstraint: NSLayoutConstraint!
    @IBOutlet private weak var detailViewWidthConstraint: NSLayoutConstraint!
    @IBOutlet private weak var collectionView: UICollectionView!
    @IBOutlet private weak var detailView: UIView!
    
    // MARK: Properties
    private var cancellables = Set<AnyCancellable>()
    private var viewModel: SomeViewModel?
    var detailVC: UIViewController?
    
    // MARK: Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupCollectionView()
        bindFetchData()
        navigationItem.rightBarButtonItem = UIBarButtonItem.init(title:NSLocalizedString("Done", comment: ""), style: .plain, target: self, action: #selector(dissmissController))
    }
    
    /// This  function init with coordinator and used to setup the View Model
    func initWithCoordinator(coordinator: AppCoordinator?) {
        viewModel = SomeViewModel(appCoordinator: coordinator)
    }
    
    @objc func dissmissController() {}
    
    // MARK: IBActions
    @IBAction func closeshowDetails() {
        animateDetailView(width: 0) { [weak self] in
            self?.detailVC?.removeFromParent()
        }
    }
    
    @IBAction func showDetail() {
        animateDetailView(width: 100) { [weak self] in
            guard let detailView = self?.detailView else { return }
            self?.view.addSubview(detailView)
        }
    }
}

private extension SomeViewController {
    func setupCollectionView() {
        collectionView.dataSource = self
        collectionView.delegate = self
        collectionView.registerNib(forCellClass: UICollectionViewCell.self)
    }
    
    /// Binds the data reloading mechanism of the ViewModel to the UI.
    /// This function sets up a subscription to the `reloadData` publisher
    /// and updates the UI based on the received result.
    ///
    /// If the data reload is successful, the UI will be refreshed.
    /// Errors encountered during reloading are not handled here and should be managed appropriately where this function is called.
    func bindFetchData() {
        viewModel?.reloadData.sink(receiveValue: { [weak self] result in
            switch result {
            case .success():
                self?.reloadData()
            case .failure(_): break
                // Handle Error
            }
        }).store(in: &cancellables)
    }
    
    func reloadData() {
        collectionView.reloadData()
    }
    
    /// Animates the width of a detail view with a specified duration.
    ///
    /// This function adjusts the width constraint of a detail view and
    /// animates the change over a duration of 0.5 seconds. Upon animation completion,
    /// the provided completion closure is executed.
    ///
    /// - Parameters:
    ///   - width: The desired width for the detail view after animation.
    ///   - completion: A closure to execute when the animation completes.
    func animateDetailView(width: CGFloat, completion: @escaping () -> Void) {
        detailViewWidthConstraint.constant = width
        UIView.animate(withDuration: 0.5) { [weak self] in
            self?.view.layoutIfNeeded()
        } completion: { _ in
            completion()
        }
    }
}

extension SomeViewController: UICollectionViewDelegateFlowLayout {
    open func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        var widthMultiplier: CGFloat = 0.2929
        if isIPhone() {
            widthMultiplier = 0.9
        }
        return CGSize(width: view.frame.width * widthMultiplier , height: 150.0)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        let frameWidth = (view.frame.width * 0.2929 * 3) + 84
        var minSpacing: CGFloat = (view.frame.width - frameWidth)/2
        if isIPhone() {
            minSpacing = 24
        }
        return minSpacing
    }
}

extension SomeViewController: UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        viewModel?.numberOfData ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        UICollectionViewCell()
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        showDetail()
    }
}


